package com.example.musicapplicationtemplate.utils;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.example.musicapplicationtemplate.R;
import com.example.musicapplicationtemplate.model.Song;

public class MusicPlayerManager {
    private static MusicPlayerManager instance;
    private MediaPlayer mediaPlayer;
    private List<Song> playlist;
    private Song currentSong;
    private int currentIndex;
    private boolean isPlaying;
    private boolean isShuffle;
    private int repeatMode;
    private OnPlaybackChangeListener playbackChangeListener;
    private OnSeekBarChangeListener seekBarChangeListener;
    private OnUIUpdateListener uiUpdateListener;
    private Handler seekBarHandler = new Handler();

    public interface OnSongCompleteListener {
        void onSongComplete();
    }
    public interface OnSongChangedListener {
        void onSongChanged();
    }
    private OnSongChangedListener songChangedListener;
    public void setOnSongChangedListener(OnSongChangedListener listener) {
        this.songChangedListener = listener;
    }
    private MusicPlayerManager() {
        mediaPlayer = new MediaPlayer();
        playlist = new ArrayList<>();
        currentIndex = 0;
        isPlaying = false;
        isShuffle = false;
        repeatMode = 0;
    }

    public static MusicPlayerManager getInstance() {
        if (instance == null) {
            instance = new MusicPlayerManager();
        }
        return instance;
    }

    public void setPlaylist(List<Song> playlist, int index) {
        if (playlist == null || playlist.isEmpty()) {
            Log.e("MusicPlayerManager", "setPlaylist: Danh sách bài hát rỗng!");
            return;
        }

        this.playlist = playlist;
        this.currentIndex = index;
        this.currentSong = playlist.get(index);

        Log.d("MusicPlayerManager", "setPlaylist: Playlist có " + playlist.size() + " bài hát.");

        if (uiUpdateListener != null) {
            uiUpdateListener.onUIUpdate(currentSong);
        }
    }

    public void playSong(Context context, Song song) {
        try {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.reset();
            int resId = context.getResources().getIdentifier(
                    song.getFile_path().substring(0, song.getFile_path().lastIndexOf(".")),
                    "raw", context.getPackageName());
            if (resId != 0) {
                mediaPlayer = MediaPlayer.create(context, resId);
                mediaPlayer.setOnCompletionListener(mp -> handleSongCompletion(context));
                mediaPlayer.start();
                currentSong = song;
                isPlaying = true;
                if (uiUpdateListener != null) {
                    uiUpdateListener.onUIUpdate(currentSong);
                }
                startSeekBarUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void handleSongCompletion(Context context) {
        if (repeatMode == 2) { // Repeat One
            playSong(context, playlist.get(currentIndex));
        } else if (isShuffle) { // Shuffle mode
            currentIndex = new Random().nextInt(playlist.size());
            playSong(context, playlist.get(currentIndex));
        } else { // Next song
            playNext(context);
        }

        // Cập nhật giao diện sau khi chuyển bài
        if (uiUpdateListener != null) {
            uiUpdateListener.onUIUpdate(currentSong);
        }
    }
    private void startSeekBarUpdate() {
        seekBarHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (seekBarChangeListener != null) {
                    seekBarChangeListener.onSeekBarUpdate(getCurrentPosition());
                }
                seekBarHandler.postDelayed(this, 500);
            }
        }, 500);
    }

    public void togglePlayPause() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
                isPlaying = false;
            } else {
                mediaPlayer.start();
                isPlaying = true;
                startSeekBarUpdate();
            }
        }
    }

    public void seekTo(int position) {
        if (mediaPlayer != null) {
            mediaPlayer.seekTo(position);
        }
    }

    public Song getCurrentSong() {
        return currentSong;
    }

    public boolean isPlaying() {
        return isPlaying;
    }

    public int getCurrentPosition() {
        return mediaPlayer != null ? mediaPlayer.getCurrentPosition() : 0;
    }

    public int getDuration() {
        return (mediaPlayer != null && currentSong != null) ? mediaPlayer.getDuration() : 0;
    }
    public void setShuffle(boolean shuffle) {
        this.isShuffle = shuffle;
    }

    public void setRepeatMode(int mode) {
        this.repeatMode = mode;
    }

    public void playNext(Context context) {
        if (playlist == null || playlist.isEmpty()) {
            Log.e("MusicPlayerManager", "Danh sách bài hát trống! Không thể phát bài tiếp theo.");
            return;
        }

        Log.d("MusicPlayerManager", "Số bài hát trong playlist: " + playlist.size());

        if (isShuffle) {
            currentIndex = new Random().nextInt(playlist.size()); // Chơi bài ngẫu nhiên
        } else {
            currentIndex = (currentIndex + 1) % playlist.size(); // Chuyển bài tiếp theo
        }

        playSong(context, playlist.get(currentIndex));

        // Cập nhật giao diện
        Log.d("uiUpdateListener","uiUpdateListener: "+uiUpdateListener);
        if (uiUpdateListener != null) {

            uiUpdateListener.onUIUpdate(currentSong);
        }
    }

    public void playPrevious(Context context) {
        if (playlist == null || playlist.isEmpty()) {
            Log.e("MusicPlayerManager", "Danh sách bài hát trống! Không thể phát bài trước đó.");
            return;
        }

        Log.d("MusicPlayerManager", "Số bài hát trong playlist: " + playlist.size());

        if (isShuffle) {
            currentIndex = new Random().nextInt(playlist.size());
        } else {
            currentIndex = (currentIndex - 1 + playlist.size()) % playlist.size();
        }

        playSong(context, playlist.get(currentIndex));

        // Cập nhật giao diện
        if (uiUpdateListener != null) {
            uiUpdateListener.onUIUpdate(currentSong);
        }
    }

    public void setOnPlaybackChangeListener(OnPlaybackChangeListener listener) {
        this.playbackChangeListener = listener;
    }

    public void setOnSeekBarChangeListener(OnSeekBarChangeListener listener) {
        this.seekBarChangeListener = listener;
    }

    public void setOnUIUpdateListener(OnUIUpdateListener listener) {
        this.uiUpdateListener = listener;
    }

    public interface OnPlaybackChangeListener {
        void onSongComplete();
    }
    public void toggleRepeat() {
        repeatMode = (repeatMode + 1) % 3;
    }
    public interface OnSeekBarChangeListener {
        void onSeekBarUpdate(int progress);
    }

    public interface OnUIUpdateListener {
        void onUIUpdate(Song song);
    }
}