package com.example.musicapplicationtemplate;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PlayerActivity extends AppCompatActivity {
    private ImageView playerImage, playerPlayPause, playerPrevious, playerNext;
    private TextView playerTitle, playerArtist;
    private Handler handler = new Handler();
    private MusicPlayerManager musicPlayerManager;
    private SeekBar seekBarPlayer;
    private BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(MusicService.ACTION_UPDATE_SEEKBAR.equals(intent.getAction())){
                int currentPosition = intent.getIntExtra(MusicService.EXTRA_CURRENT_POSITION, 0);
                seekBarPlayer.setProgress(currentPosition);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        playerImage = findViewById(R.id.player_image);
        playerTitle = findViewById(R.id.player_title);
        playerArtist = findViewById(R.id.player_artist);
        playerPlayPause = findViewById(R.id.player_play_pause);
        playerPrevious = findViewById(R.id.player_previous);
        playerNext = findViewById(R.id.player_next);

        musicPlayerManager = MusicPlayerManager.getInstance();

        // Lấy id seekbar theo file giao diện của PlayerActivity
        seekBarPlayer = findViewById(R.id.seekBarMiniPlayer);

        seekBarPlayer.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(fromUser){
                    Intent intent = new Intent(PlayerActivity.this, MusicService.class);
                    intent.setAction("ACTION_SEEKBAR_CHANGE");
                    intent.putExtra("progress", progress);
                    startService(intent);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            registerReceiver(updateReceiver, new IntentFilter(MusicService.ACTION_UPDATE_SEEKBAR), Context.RECEIVER_NOT_EXPORTED);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(updateReceiver);
    }
}
